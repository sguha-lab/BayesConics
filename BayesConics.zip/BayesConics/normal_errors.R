

fnB.log.lik <- function(data, tmp.parm)
{
  
  h <- tmp.parm$aligned$h
  k <- tmp.parm$aligned$k
  a <- tmp.parm$aligned$a
  b <- tmp.parm$aligned$b
  psi <- tmp.parm$aligned$psi
  t.v <- tmp.parm$t.v
  n <- data$n
  
  tmp.parm$x.v <- h + a*cos(t.v)*cos(psi) - b*sin(t.v)*sin(psi)
  tmp.parm$y.v <- k + a*cos(t.v)*sin(psi) + b*sin(t.v)*cos(psi)
  
  eps_sq.v <- (data$x.v-tmp.parm$x.v)^2 + (data$y.v-tmp.parm$y.v)^2
  
  tmp.parm$log.lik <- -.5/tmp.parm$sigma^2*sum(eps_sq.v)
  
  tmp.parm$log.lik <- tmp.parm$log.lik - n*log(2*pi) -2*n*log(tmp.parm$sigma)
  
  tmp.parm$log.lik
}


fnB.init_ellipse <- function(data, mh_psi_const, mh_ti_const)

	{

	################################################################
	# LINEAR LEAST-SQUARES (PSEUDO-INVERSE)
	# SEE ABSTRACT FOR CONFIRMATION THAT PSEUDO-INVERSE IS
	# ONE OF THE TWO LINEAR LS METHODS (OTHER BEING EIGEN ANALYSIS)
	################################################################

	## p. 60 of Sujit da's version
	## Using same overloaded notation as Zhang to find p.v

	b <- -data$y.v^2
	A <- array(,c(data$n,5))
	A[,1] <- data$x.v^2-data$y.v^2
	A[,2] <- 2*data$x.v*data$y.v
	A[,3] <- 2*data$x.v
	A[,4] <- 2*data$y.v
	A[,5] <- 1

	tA.A <- t(A)%*%A
	p.v <- as.vector(solve(tA.A) %*% t(A)%*%b)

	# now fill in C and expand to full parameter vector
	p_parm.v <- array(,6)
	p_parm.v[-3] <- p.v
	p_parm.v[3] <- 1 - p.v[1] 

	##################################

	parm <- NULL
	parm$p.v <- p_parm.v

	parm$check_elps <- fn_is.elps(parm$p.v)
	if (!parm$check_elps) 
		{stop("Not an ellipse!")
		}

	parm$A <- p_parm.v[1]
	parm$B <- p_parm.v[2]
	parm$C <- p_parm.v[3]
	parm$D <- p_parm.v[4]
	parm$E <- p_parm.v[5]
	parm$F <- p_parm.v[6]

	#####

	parm$aligned <- fn_canonical_to_aligned.elps(parm$p.v)
	# using only psi for angle in Bayesian
	parm$aligned$angle <- NULL
	
	################
	# 	COMPUTE t_i's for current state
	###############
	
	parm <- fn2_ortho_dist(data, parm)
	parm$t.v <- parm$min_t.v
	parm$min_t.v <- NULL
	
	################
	# 	sigma
	###############
	
	parm <- fnB.sigma(data, parm)
	
	parm$mh_psi_const <- mh_psi_const
	parm$mh_ti_const <- mh_ti_const
	
	################
	# 	Bernstein degree
	###############
	
	parm$bern_degree <- bern_degree 
  parm$p_t.v <- rgamma(n=(parm$bern_degree+1),shape=1)
  parm$p_t.v <- parm$p_t.v / sum(parm$p_t.v)
  
  parm$t_bern.v <- sample(1:(parm$bern_degree+1),size=data$n, replace=TRUE)
  
	parm
	}


fnB.sigma <- function(data, parm)
{
  h <- parm$aligned$h
  k <- parm$aligned$k
  a <- parm$aligned$a
  b <- parm$aligned$b
  psi <- parm$aligned$psi
  t.v <- parm$t.v
  
  parm$x.v <- h + a*cos(t.v)*cos(psi) - b*sin(t.v)*sin(psi)
  parm$y.v <- k + a*cos(t.v)*sin(psi) + b*sin(t.v)*cos(psi)
  
  eps_sq.v <- (data$x.v-parm$x.v)^2 + (data$y.v-parm$y.v)^2
  
  parm$sigma <- 1/sqrt(rgamma(n=1, shape=(data$n+1), rate=sum(eps_sq.v)/2))
  
  parm
}

fnB.gen_center <- function(data, parm)
	{

	
	h <- parm$aligned$h
	k <- parm$aligned$k
	a <- parm$aligned$a
	b <- parm$aligned$b
	psi <- parm$aligned$psi
	t.v <- parm$t.v
	
	parm$x.v <- data$x.v -a*cos(t.v)*cos(psi) +b*sin(t.v)*sin(psi)
	parm$y.v <- data$y.v -a*cos(t.v)*sin(psi) -b*sin(t.v)*cos(psi)

	parm$mu.v <- c(mean(parm$x.v), mean(parm$y.v))
	parm$sd.mt <- parm$sigma*diag(2)/data$n

	vec <- rmvnorm(n=1, mean=parm$mu.v, sigma=parm$sd.mt)
		

	parm$aligned$h <- vec[1]
	parm$aligned$k <- vec[2]
		
	parm	
	}


fnB.gen_axes <- function(data, parm)
	{

	h <- parm$aligned$h
	k <- parm$aligned$k
	a <- parm$aligned$a
	b <- parm$aligned$b
	psi <- parm$aligned$psi
	t.v <- parm$t.v
	n <- data$n

	parm$x.v <- data$x.v -h
	parm$y.v <- data$y.v -k

	parm$D.mt <- array(,c(2*n,2))
	parm$D.mt[1:n,] <- c(cos(t.v)*cos(psi), -sin(t.v)*sin(psi))
	parm$D.mt[-(1:n),] <- c(cos(t.v)*sin(psi), sin(t.v)*cos(psi))
	D <- parm$D.mt

	parm$w.v <- c(parm$x.v, parm$y.v)
	
	M <- solve(t(D)%*%D)
	parm$mu.v <- as.vector(M %*% t(D)%*%parm$w.v)
	parm$sd.mt <- parm$sigma^2*M

  vec <- rmvnorm(n=1, mean=parm$mu.v, sigma=parm$sd.mt)
		
	parm$aligned$a <- vec[1]
	parm$aligned$b <- vec[2]

	parm	
	}


log.dens.psi <- function(psi_star, data, parm)
{ 
  tmp.parm <- parm
  tmp.parm$aligned$psi <- psi_star
  
  fnB.log.lik(data, tmp.parm)
  
}

deri_L.psi <- function(psi_star, data, parm, eps=2*pi/1000)
  {

  val1  <- log.dens.psi((psi_star+eps/2), data, parm)
  val2 <- log.dens.psi((psi_star-eps/2), data, parm)
  
  (val1-val2)/eps
  }

deri2_L.psi2 <- function(psi_star, data, parm, eps=2*pi/1000)
{

  val1  <- deri_L.psi((psi_star+eps), data, parm)
  val2 <- deri_L.psi((psi_star-eps), data, parm)
  
  (val1-val2)/eps/2
}



fnB.gen_psi <- function(data, parm, mh_psi_const)
{
  
  psi_sd <- parm$mh_psi_const/sqrt(-deri2_L.psi2(psi_star=parm$aligned$psi, data, parm, eps=2*pi/1000))
  
  new.parm <- parm
  # keeping psi between [-pi/2,pi/2]
  lower.u <- pnorm(-pi/2,mean=parm$aligned$psi,sd=psi_sd)
  upper.u <- pnorm(pi/2,mean=parm$aligned$psi,sd=psi_sd)
  u <- runif(n=1, min=lower.u, max=upper.u)
  new.parm$aligned$psi <- qnorm(u,mean=parm$aligned$psi,sd=psi_sd)
  
  log.ratio <- log.dens.psi(psi_star=new.parm$aligned$psi, data, parm) - log.dens.psi(psi_star=parm$aligned$psi, data, parm)
  log.ratio <- min(log.ratio,0)
  psi_flip <- rbinom(n=1,size=1,prob=exp(log.ratio))
  
  if (psi_flip==1)
    {parm <- new.parm
    }
  
  parm$psi_flip <- psi_flip
  
  parm	
}

log.prior.t_i <- function(t_star, parm, summ=TRUE)
{ val <- array(,(parm$bern_degree+1))

  # in some rare cases on the edges of support
  # warp around

  wrap_scale_t <- t_star/2/pi
  if (wrap_scale_t > 1)
  {wrap_scale_t <- wrap_scale_t - 1}
  if (wrap_scale_t < 0)
  {wrap_scale_t <- wrap_scale_t + 1}


  for (w in 1:(parm$bern_degree+1))
  {val[w] <- parm$p_t.v[w] * dbeta(wrap_scale_t, shape1=w, shape2=(parm$bern_degree+2-w))
  }

  maxx <- max(val)
  
  val <- val/maxx
  
  if (summ)
    {ret <- log(maxx) + log(sum(val))
    }
  
  if (!summ)
    {ret <- val
  }
  
  ret
}

log.dens.t_i <- function(t_star, i, data, parm)
{ h <- parm$aligned$h
  k <- parm$aligned$k
  a <- parm$aligned$a
  b <- parm$aligned$b
  psi <- parm$aligned$psi
  sigma <- parm$sigma

  x <- h + a*cos(t_star)*cos(psi) - b*sin(t_star)*sin(psi)
  y <- k + a*cos(t_star)*sin(psi) + b*sin(t_star)*cos(psi)
  
  eps_sq.i <- (data$x.v[i]-x)^2 + (data$y.v[i]-y)^2
  
  # ignoring scaling constants that don't depend on t_i
  val <- -.5/sigma^2*eps_sq.i
  
  val <- val + log.prior.t_i(t_star, parm, summ=TRUE)
  
  val
}


deri_L.t_i <- function(t_star, i, data, parm, eps=2*pi/1000)
{
  
  val1  <- log.dens.t_i((t_star+eps/2), i, data, parm)
  val2 <- log.dens.t_i((t_star-eps/2), i, data, parm)
  
  (val1-val2)/eps
}


deri2_L.t_i2 <- function(t_star, i, data, parm, eps=2*pi/1000)
{

  val1  <- deri_L.t_i((t_star+eps), i, data, parm)
  val2 <- deri_L.t_i((t_star-eps), i, data, parm)
  
  (val1-val2)/eps/2
}


fn.gen_t_i <- function(i, data, parm)
  {
  der2 <- deri2_L.t_i2(t_star=parm$t.v[i], i, data, parm)
  parm$convex_i.flag.v[i] <- as.numeric(der2 > 0)
  
  ti_sd <- parm$mh_ti_const/sqrt(abs(der2))
  
  new.parm <- parm
  # keeping t between [0,2*pi]
  lower.u <- pnorm(0,mean=parm$t.v[i],sd= ti_sd)
  upper.u <- pnorm(2*pi,mean=parm$t.v[i],sd= ti_sd)
  u <- runif(n=1, min=lower.u, max=upper.u)
  new.parm$t.v[i] <- qnorm(u,mean=parm$t.v[i],sd=ti_sd)
  
  log.ratio <- log.dens.t_i(t_star=new.parm$t.v[i], i, data, parm) - log.dens.t_i(t_star=parm$t.v[i], i, data, parm)
  log.ratio <- min(log.ratio,0)
  ti_flip <- rbinom(n=1,size=1,prob=exp(log.ratio))
  
  if (ti_flip==1)
  {parm <- new.parm
  }
  
  parm$ti_flip.v[i] <- ti_flip
  
  
  parm
}


fn.sample <- function(prob.v)
  {sample(1:length(prob.v), size=1, prob=prob.v)
}



fn.bern.component <- function(parm)
{
 
  
  prob.mt <- array(,c(data$n, (parm$bern_degree+1)))
  
  for (w in 1:(parm$bern_degree+1))
    {prob.mt[,w] <- parm$p_t.v[w] * dbeta(parm$t.v/2/pi, shape1=w, shape2=(parm$bern_degree+2-w))
    }
    
  parm$t_bern.v <- apply(prob.mt,1,fn.sample)
  
  parm$t_bern_summary.v <- array(,(parm$bern_degree+1))
  for (w in 1:(parm$bern_degree+1))
    {parm$t_bern_summary.v[w] <- sum(parm$t_bern.v==w)
    }
  
  parm$p_t.v <- rgamma(n=(parm$bern_degree+1),shape=(1+parm$t_bern_summary.v))
  parm$p_t.v <- parm$p_t.v / sum(parm$p_t.v)
  
  parm
  
  }
  
  

fn.gen_t.v <- function(data, parm)
  {
  h <- parm$aligned$h
  k <- parm$aligned$k
  a <- parm$aligned$a
  b <- parm$aligned$b
  psi <- parm$aligned$psi
  sigma <- parm$sigma9
  
  t.v <- parm$t.v
  
  parm$convex_i.flag.v <- parm$ti_flip.v <- rep(NA,data$n)
  
  for (i in 1:data$n)
    {parm <- fn.gen_t_i(i, data, parm)
    t.v <- parm$t.v
    }
  
  parm
  
}



fnB.iter_ellipse <- function(data, parm)

	{

	################
	# 	UPDATE (h,k)
	###############
	
	parm <- fnB.gen_center(data, parm)


	################
	# 	UPDATE (a,b)
	###############
	
	parm <- fnB.gen_axes(data, parm)
	
	################
	# 	sigma
	###############
	
	parm <- fnB.sigma(data, parm)


	################
	# 	UPDATE psi
	###############
	
	parm <- fnB.gen_psi(data, parm)

	################
	# 	COMPUTE t_i's 
	###############

	parm <- fn.gen_t.v(data, parm)
	
	#############
	## Now generate the components of Bernstein polynomial
	## and update their probabilities
	#############
	
	parm <- fn.bern.component(parm)
	
	parm
	}





fnB.main_ellipse <- function(data, n.burn,n.reps, mh_psi_const, mh_ti_const)
  
{parm <- fnB.init_ellipse(data, mh_psi_const, mh_ti_const)

  for (cc in 1:n.burn)
    {parm <- fnB.iter_ellipse(data, parm)
    
    if (cc %% 10 == 0)
    {print(paste("BURNIN",cc,date()))
    }
  }

  All.Stuff <- NULL
  All.Stuff$convex_i.flag.v <- All.Stuff$ti_flip.v <- rep(0,data$n)
  All.Stuff$psi_flip <- 0
  All.Stuff$aligned.mt <- array(0,c(length(parm$aligned), n.reps))
  All.Stuff$sigma <- 0
  All.Stuff$p_t.v <- rep(0,(parm$bern_degree+1))

  for (cc in 1:n.reps)
    {parm <- fnB.iter_ellipse(data, parm)
    
    All.Stuff$aligned.mt[,cc] <- unlist(parm$aligned)
    
    All.Stuff$convex_i.flag.v <- All.Stuff$convex_i.flag.v + parm$convex_i.flag.v
    All.Stuff$ti_flip.v <- All.Stuff$ti_flip.v + parm$ti_flip.v
    
    All.Stuff$psi_flip <- All.Stuff$psi_flip + parm$psi_flip
    
    All.Stuff$sigma <- All.Stuff$sigma + parm$sigma
    
    All.Stuff$p_t.v <- All.Stuff$p_t.v + parm$p_t.v
    
    if (cc %% 10 == 0)
    {print(paste("ANALYZING",cc,date()))
    }
  }

  All.Stuff$convex_i.flag.v <- All.Stuff$convex_i.flag.v/n.reps
  All.Stuff$ti_flip.v <- All.Stuff$ti_flip.v/n.reps
  All.Stuff$psi_flip <- All.Stuff$psi_flip/n.reps
  All.Stuff$sigma <- All.Stuff$sigma/n.reps
  All.Stuff$p_t.v <- All.Stuff$p_t.v/n.reps
  
  All.Stuff$parm <- parm

  All.Stuff
}

# All.Stuff <- fnB.main_ellipse(data, n.burn=50,n.reps=100,mh_psi_const = .5, mh_ti_const = .05)

