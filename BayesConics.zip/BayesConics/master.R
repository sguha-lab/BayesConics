
rm(list=ls())

library(MASS)
library(stats) 
library(mvtnorm)

options(error=recover)

source("ellipse_representations.R")
source("hyperbola_representations.R")
source("parabola_representations.R")

source("gen_data.R")

source("orthogonal_distance_DE.R")
source("DE.R")

true <- NULL
true$h <- true$k <- 250 

###################################### 
# Set Univariate Gaussian error SD 
# for n simulation data points
###################################### 

true$n <- 100
true$sigma <- 2

######################################
# how many datasets?
######################################
num.reps <- 300

######################################
# MCMC
######################################

n.burn=100
n.reps=200

mh_psi_const = 2
mh_ti_const = 2
mh_l_const = 2
mh_e_const = 2

Big_h <- Big_k <- Big_l <- Big_sigma <- 1e5

# Bernstein polynomials
bern_degree <- round(true$n/log(true$n))

########## GENERATE DATA AND ANALYZE
########## Results in result$est.mt and result$se.mt

################################
# Directrix-Eccentricity (DE) 
#################################

de <- NULL
de$psi_flip.v <- de$e_flip.v <- de$l_flip.v <- array(,num.reps)
de$ti_flip.mt <-  array(,c(true$n,num.reps))
de$ti_convex.mt <-  array(,c(true$n,num.reps))
de$e_convex.v <- de$conics.v <- de$sigma.v <- array(,num.reps)
de$est_parm.mt = array(,c(6,num.reps))
de$ConicsProbs = array(,c(3,num.reps))
de$postCorr = array(,c(5,5,num.reps))
dimnames(de$est_parm.mt) = list(c("h", "k", "psi", "e", "l", "sigma"), NULL)
dimnames(de$postCorr) = list(c("h", "k", "psi", "e", "l"), c("h", "k", "psi", "e", "l"), NULL)

de$est_parm.mt = array(,c(6,num.reps))

de$secondsPerIteration = array(,num.reps)
  
true$e.v <- true$e_cat.v <- true$psi.v <- array(,num.reps)

###################################### 
# Generate data and make inferences
# for num.reps datasets
###################################### 

for (xxx in 1:num.reps)
{
  tmp <- fn.genConics(true, xxx)
  data <- tmp[[1]]
  true <- tmp[[2]]
  rm(tmp)
  
  true$e.v[xxx] <- true$e
  true$e_cat.v[xxx] <- true$e_cat
  true$psi.v[xxx] <- true$psi
  
  ################################
  # Directrix-Eccentricity (DE) 
  #################################
  
  DE.Stuff <- fnDE.main_conic(data, n.burn,n.reps, mh_psi_const, mh_ti_const, mh_l_const, mh_e_const, Big_h, Big_k, Big_l, Big_sigma)
  
  de$psi_flip.v[xxx] <- DE.Stuff$psi_flip
  de$e_flip.v[xxx] <- DE.Stuff$e_flip
  de$l_flip.v[xxx] <- DE.Stuff$l_flip
  de$ti_flip.mt[,xxx] <-  DE.Stuff$ti_flip.v
  de$ti_convex.mt[,xxx] <-  DE.Stuff$convex_i.flag.v
  de$sigma.v[xxx] <- DE.Stuff$sigma
  
  de$conics.v[xxx]= DE.Stuff$detectedConic
  de$e_convex.v[xxx]= mean(DE.Stuff$convex_e.flag)
  de$est_parm.mt[,xxx]= rowMeans(DE.Stuff$parm.mt)
  
  de$ConicsProbs[,xxx] = DE.Stuff$conicsProbs
  
  de$postCorr[,,xxx] = DE.Stuff$cor.mt[-6,-6]
  
  de$secondsPerIteration[xxx] = DE.Stuff$diffTime
  
  print(" ")
  print("#####################")
  print(paste("#### DATASET", xxx, "####"))
  print("#####################")
  print(" ")
  
  save.image()
  
}

  ######################################################
  ### Table 3 results 
  #######################################################
  
  source("DE_checkResults.R")

  # Monte Carlo estimates of the posterior 
  # probabilities of classifi-cation 
  # for the three true conic section types
  print(results$conditionalConicsMatch)
  
  # standard errors 
  print(results$conditionalConicsProbs_SE)


  
