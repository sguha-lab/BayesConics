
fn_dist <- function(t, data, parm, i)
	{
	h <- parm$aligned$h
	k <- parm$aligned$k
	a <- parm$aligned$a
	b <- parm$aligned$b
	psi <- parm$aligned$psi

	term <- array(,2)
	term[1] <- data$x.v[i] -h -a*cos(t)*cos(psi) +b*sin(t)*sin(psi)
	term[2] <- data$y.v[i] -k -a*cos(t)*sin(psi) -b*sin(t)*cos(psi)
	
	sqrt(term[1]^2 + term[2]^2)
	}



fn2_ortho_dist <- function(data, parm)
	{min_t.v <- min_dist.v <- array(,data$n)

	for (i in 1:data$n)
		{tmp <- optimize(fn_dist, interval=c(0,2*pi), data, parm, i)
		min_t.v[i] <- tmp$minimum
		min_dist.v[i] <- tmp$objective
		}
	
	parm$min_t.v <- min_t.v
	parm$min_dist.v <- min_dist.v 
	
	h <- parm$aligned$h
	k <- parm$aligned$k
	a <- parm$aligned$a
	b <- parm$aligned$b
	psi <- parm$aligned$psi

	parm$min_x.v <- h  + a*cos(parm$min_t.v)*cos(psi) -b*sin(parm$min_t.v)*sin(psi)
	parm$min_y.v <- k  + a*cos(parm$min_t.v)*sin(psi) +b*sin(parm$min_t.v)*cos(psi)

	parm
	}


