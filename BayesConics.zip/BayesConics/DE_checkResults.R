
results <- NULL

de$e.v <- de$est_parm.mt[4,]
de$psi.v <- de$est_parm.mt[3,]

results$conicsMatch = mean(de$conics.v== true$e_cat.v)
results$eRMSE = sqrt(mean((de$e.v-true$e.v)^2))
results$psiRMSE = sqrt(mean((de$psi.v-true$psi.v)^2))
results$sigmaRMSE = sqrt(mean((de$sigma.v-true$sigma)^2))

results$conditionalConicsProbs_SE = results$conditionalConicsProbs = results$conditionalConicsMatch = results$conditionalPsiRMSE = array(0,c(3,3))

for (cc in 2:4)
  {flag_cc.v = true$e_cat.v==cc
  mat.cc = de$ConicsProbs[,flag_cc.v]
  
  for (xx in 2:4)
    {flag_xx.v = de$conics.v==xx
    results$conditionalConicsMatch[(cc-1),(xx-1)] = sum(flag_cc.v*flag_xx.v)
    }
  #
  results$conditionalPsiRMSE[cc-1] = sqrt(mean((de$psi.v[flag_cc.v]-true$psi.v[flag_cc.v])^2))
  #
  results$conditionalConicsProbs[(cc-1),] = rowMeans(mat.cc)
  results$conditionalConicsProbs_SE[(cc-1),] = apply(mat.cc,1,sd)/sqrt(sum(flag_cc.v))
  }

results$psiFlip = mean(de$psi_flip.v)
results$eFlip = mean(de$e_flip.v)
results$lFlip = mean(de$l_flip.v)
results$tFlip = mean(de$ti_flip.mt)

results$eConvex= mean(de$e_convex.v)
results$tConvex= mean(de$ti_convex.mt)




