

fn.initParabola <- function(data, parm)
{
  lse <- lm(data$y_star.v^2 ~ data$x_star.v + data$y_star.v)
  beta <- as.vector(lse$coefficients)
  
  a = -.25*beta[2]
  
  k_star = beta[3]/2
  h_star = -1/beta[2] * (beta[3]^2/4 +beta[1])
  
  hk.v <- as.vector(solve(parm$rot.mt) %*% c(h_star, k_star))
  h = hk.v[1]
  k = hk.v[2]
  
  eSq = 1
  
  init_prbl <- NULL
  init_prbl$a = a
  init_prbl$e = sqrt(eSq)
  init_prbl$h = h
  init_prbl$k = k
  init_prbl$psi = parm$psi
  
  parm$init_prbl = init_prbl
  
  parm
}



fn_canonical_to_aligned.prbl <- function(p.v)
	{
	aligned <- aligned2 <- NULL

	A <- p.v[1]
	B <- p.v[2]
	C <- p.v[3]
	D <- p.v[4]
	E <- p.v[5]
	F <- p.v[6]
	
	M <- matrix(c(A,B,D,B,C,E,D,E,F),ncol=3)
	Delta <- det(M)

	J <- A*C - B^2

	aligned$psi <- .5*atan(2*B/(A-C))
  
  x_r.v <- data$x.v*cos(aligned$psi) - data$y.v*sin(aligned$psi)
  
  y_r.v <- data$x.v*sin(aligned$psi) + data$y.v*cos(aligned$psi)
  
  tmp <- lm(y_r.v^2 ~ x_r.v + y_r.v)
  lse <- as.vector(tmp$coefficients)
  
  D2 <- -.5*lse[2]
  E2 <- -.5*lse[3]
  F2 <- -lse[1]
  
  aligned$k <- -E2
  
  aligned$a = -lse[2]/4
  
  aligned$h <- (E2^2-F2)/2/D2
  
	aligned
	}




fn_aligned.prbl_to_DE <- function(parm)
{
 
  parm$de <- NULL
  
  parm$de$e <- 1
  parm$de$l <- 2*parm$aligned$a 
  
  parm$de$psi <- parm$aligned$psi
  
  parm$de$h <- parm$aligned$h - parm$aligned$a * cos(parm$aligned$psi)
  parm$de$k <- parm$aligned$k - parm$aligned$a * sin(parm$aligned$psi)
  
  parm$de$tRange = c(-pi, pi) 
  
  parm
}

fn_DE.prbl_to_aligned <- function(parm)
{
  
 parm$aligned <- NULL
 parm$aligned$a <- parm$de$l/2
 parm$aligned$psi <- parm$de$psi
  
  parm$aligned$h <- parm$de$h + parm$aligned$a * cos(parm$aligned$psi)
  parm$aligned$k <- parm$de$k + parm$aligned$a * sin(parm$aligned$psi)
  
  parm
}