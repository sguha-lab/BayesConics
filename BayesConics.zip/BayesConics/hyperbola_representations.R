
fn.initHyperbola <- function(data, parm)
{
  
  x1 <- data$x_star.v 
  x2 <- data$x_star.v^2
  
  lse <- lm(data$y_star.v^2 ~ x1 + x2 + data$y_star.v)
  beta <- as.vector(lse$coefficients)
  
  k_star = beta[4]/2
  h_star = -.5 * beta[2]/beta[3]
  
  hk.v <- as.vector(solve(parm$rot.mt) %*% c(h_star, k_star))
  h = hk.v[1]
  k = hk.v[2]
  
  eSq = 1+beta[3]
  
  b = sqrt(-beta[1] - beta[4]^2/4 + beta[2]^2/4/beta[3])
  a = sqrt(b^2/beta[3])
  
  init_hybl <- NULL
  init_hybl$a = a
  init_hybl$b = b
  init_hybl$e = sqrt(eSq)
  init_hybl$h = h
  init_hybl$k = k
  init_hybl$psi = parm$psi
  
  parm$init_hybl = init_hybl
  
  parm
}



fn_canonical_to_aligned.hypl <- function(p.v, eSq)
	{
	aligned <- aligned2 <- NULL

	A <- p.v[1]
	B <- p.v[2]
	C <- p.v[3]
	D <- p.v[4]
	E <- p.v[5]
	F <- p.v[6]
	
	M <- matrix(c(A,B,D,B,C,E,D,E,F),ncol=3)
	Delta <- det(M)

	J <- A*C - B^2

	if (J>=0)
		{stop("Not valid hyperbola")
		}
	
	aligned$psi <- .5*atan(2*B/(A-C))
	
	
	x_r.v <- data$x.v*cos(aligned$psi) - data$y.v*sin(aligned$psi)
	
	y_r.v <- data$x.v*sin(aligned$psi) + data$y.v*cos(aligned$psi)
	
  #############################
	
	x2 <- x_r.v^2 
	x1 <- x_r.v
	tmp <- lm(y_r.v^2 ~ x2 + x1 + y_r.v)
	beta <- as.vector(tmp$coefficients)
	
	aligned$k <- beta[4]/2
	
	aligned$h <- -.5*beta[3]/beta[2]
	
	aligned$b = sqrt(aligned$h^2*(eSq - 1) - aligned$k^2 - beta[1])
	
	aligned$a <- sqrt(aligned$b^2/(eSq-1))
	

  
	aligned
	}



fn_aligned.hypl_to_DE <- function(parm)
{
  parm$aligned$c <- sqrt(parm$aligned$a^2 + parm$aligned$b^2)
    
  parm$de <- NULL
  
  parm$de$e <- parm$aligned$e
  parm$de$l <- parm$aligned$a * (parm$de$e^2-1)
  
  parm$de$psi <- parm$aligned$psi
  
  parm$de$h <- parm$aligned$h - parm$aligned$c * cos(parm$aligned$psi)
  parm$de$k <- parm$aligned$k - parm$aligned$c * sin(parm$aligned$psi)
  
  parm$de$tRange = c(-acos(-1/parm$de$e), acos(-1/parm$de$e)) 
  
  parm
}

fn_DE.hypl_to_aligned <- function(parm)
{
  
 parm$aligned <- NULL
 parm$aligned$a <- parm$de$l/(parm$de$e^2-1)
 parm$aligned$b <- sqrt(parm$aligned$a*parm$de$l)
 parm$aligned$psi <- parm$de$psi
  
  c <- sqrt(parm$aligned$a^2 + parm$aligned$b^2)
  
  parm$aligned$h <- parm$de$h + c * cos(parm$aligned$psi)
  parm$aligned$k <- parm$de$k + c * sin(parm$aligned$psi)
  
  parm
}