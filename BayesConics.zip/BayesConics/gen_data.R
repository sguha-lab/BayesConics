
fn.rotateAndShiftObject <- function(true)
{
  # rotate 
  true$x2.v <- true$x0.v*cos(true$psi) - true$y0.v*sin(true$psi)
  true$y2.v <- true$x0.v*sin(true$psi) + true$y0.v*cos(true$psi)
  
  #  shift 
  true$x.v <- true$h + true$x2.v
  true$y.v <- true$k + true$y2.v
  
  # rotate center
  true$plotCenter2 = array(,2)
  true$plotCenter2[1] = true$plotCenter0[1]*cos(true$psi) - true$plotCenter0[2]*sin(true$psi)
  true$plotCenter2[2] = true$plotCenter0[1]*cos(true$psi) - true$plotCenter0[2]*sin(true$psi)
  
  #  shift 
  true$plotCenter = array(,2)
  true$plotCenter[1] <- true$h + true$plotCenter2[1]
  true$plotCenter[2] <- true$k + true$plotCenter2[2]
  
  true
}

fn.genConics <- function(true, xxx)
	{
  
  ###################################### 
  ## SET TRUE ELLIPSE PARAMETERS
  ######################################
  
  true$a <- rnorm(n=1,mean=50,sd=2)
  true$b <- rnorm(n=1,mean=25,sd=2)
  
  # 2 -- ellipse; 3 -- parabola; 4 -- hyperbola
  # NOT USED: 1 -- circle
  true$e_cat = xxx %% 3 + 2 #sample(2:4, size=1)
  
  # for a hyperbola/parabola/semi-ellipse, true$psi = 0 is left opening
  true$psi = runif(n=1,min=-pi,max=pi)
  
  if (true$e_cat == 2)
    {
    
    true$e = sqrt(1-true$b^2/true$a^2)
    
    # just left half 
    true$tRange = c(-pi/2, pi/2) 
    
    true$t.v <-  sort(runif(n=true$n,min=true$tRange[1],max=true$tRange[2]))
    
    true$x0.v <- true$a*cos(true$t.v) 
	  true$y0.v <- true$b*sin(true$t.v)
	  
	  # for plots
	  true$plotCenter0 = c(true$a*cos(0),true$b*sin(0))
	  
	  true <- fn.rotateAndShiftObject(true)

	  true$A <- (cos(true$psi))^2/true$a^2 + (sin(true$psi))^2/true$b^2
	  
	  true$C <- (sin(true$psi))^2/true$a^2 + (cos(true$psi))^2/true$b^2
	  
	  true$B <- sin(true$psi)*cos(true$psi) *(1/true$a^2 - 1/true$b^2) 

	  # possibly never used
	  true$l = true$b^2/true$a
  }
  
  if (true$e_cat == 4)
  {
    true$e = sqrt(1+true$b^2/true$a^2)
    
    trueRange=acos(-1/true$e)
    reducedRange = trueRange
    true$tRange = c(-reducedRange, reducedRange) 
    
    true$t.v <-  sort(runif(n=true$n,min=true$tRange[1],max=true$tRange[2]))
    
    true$x0.v <- -true$a*cosh(true$t.v)
    true$y0.v <- true$b*sinh(true$t.v) 
    
    # for plots
    true$plotCenter0 = c(-true$a*cosh(0),true$b*sinh(0))
    
    true <- fn.rotateAndShiftObject(true)
  
    true$l = true$b^2/true$a
  }
  
  if (true$e_cat == 3)
  {
  
    true$e = 1
    
    true$tRange = c(-2,2) 
    
    true$t.v <-  sort(runif(n=true$n,min=true$tRange[1],max=true$tRange[2]))
    
    true$x0.v <- -true$a*true$t.v^2
    true$y0.v <- 2*true$a*true$t.v
    
    # for plots
    true$plotCenter0 = c(-true$a*0^2,2*true$a*0)
    
    true <- fn.rotateAndShiftObject(true)
    
    true$l = 2*true$a
  }

	# now adding noise
	r.v <- true$sigma * sqrt(rgamma(n=true$n, shape=2/2, scale=2))
	alpha.v <- runif(n=true$n, max=2*pi)
	
	true$err_x.v <- r.v*cos(alpha.v)
	true$err_y.v <- r.v*sin(alpha.v)

	data <- NULL
	data$n <- true$n
	data$x.v <- true$x.v + true$err_x.v
	data$y.v <- true$y.v + true$err_y.v

	list(data,  true)
	}

