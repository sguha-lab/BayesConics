
fnDE_dist <- function(t, data, parm, i)
	{
  
  l <- parm$de$l
  e <- parm$de$e
  h <- parm$de$h
  k <- parm$de$k
  psi <- parm$de$psi
  t_i <- t
  r_i <- l/(1+e*cos(t_i))
  
  x_i <- h + r_i*cos(t_i+psi)
  y_i <- k + r_i*sin(t_i+psi)

	term <- array(,2)
	term[1] <- data$x.v[i] -x_i
	term[2] <- data$y.v[i] -y_i
	
	sqrt(term[1]^2 + term[2]^2)
	}



fnDE_ortho_dist <- function(data, parm)
	{min_t.v <- min_dist.v <- array(,data$n)

	for (i in 1:data$n)
		{tmp <- optimize(fnDE_dist, interval=parm$de$tRange, data, parm, i)
		# angles in range negative to positive
		min_t.v[i] <- tmp$minimum
		min_dist.v[i] <- tmp$objective
		}
	
	parm$de$min_t.v <- min_t.v
	parm$de$min_dist.v <- min_dist.v 
	
	l <- parm$de$l
	e <- parm$de$e
	h <- parm$de$h
	k <- parm$de$k
	psi <- parm$de$psi
	t.v <- parm$de$min_t.v
	r.v <- l/(1+e*cos(t.v))

	parm$de$min_x.v <- h + r.v*cos(t.v+psi)
	parm$de$min_y.v <- k + r.v*sin(t.v+psi)

	parm
	}


