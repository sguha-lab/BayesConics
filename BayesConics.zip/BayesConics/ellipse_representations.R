

fn.initEllipse <- function(data, parm)
  {
  
  x1 <- data$x_star.v 
  x2 <- data$x_star.v^2
  
  lse <- lm(data$y_star.v^2 ~ x1 + x2 + data$y_star.v)
  beta <- as.vector(lse$coefficients)
  
  k_star = beta[4]/2
  h_star = -.5 * beta[2]/beta[3]
  
  hk.v <- as.vector(solve(parm$rot.mt) %*% c(h_star, k_star))
  h = hk.v[1]
  k = hk.v[2]
  
  eSq = 1+beta[3]
  
  b = sqrt(beta[1] + beta[4]^2/4 - beta[2]^2/4/beta[3])
  a = sqrt(-b^2/beta[3])
  
  init_elps <- NULL
  init_elps$a = a
  init_elps$b = b
  init_elps$e = sqrt(eSq)
  init_elps$h = h
  init_elps$k = k
  init_elps$psi = parm$psi

  parm$init_elps = init_elps
  
  parm
  }


fn_is.elps <- function(p.v)
	{
	A <- p.v[1]
	B <- p.v[2]
	C <- p.v[3]
	D <- p.v[4]
	E <- p.v[5]
	F <- p.v[6]

	M <- matrix(c(A,B,D,B,C,E,D,E,F),ncol=3)
	Delta <- det(M)
	
	J <- A*C-B^2
	I <- A+C
	
	(J > 0) & (Delta != 0) & (Delta/I <0)
	}

fn_canonical_to_aligned.elps <- function(p.v)
	{
	aligned <- aligned2 <- NULL

	A <- p.v[1]
	B <- p.v[2]
	C <- p.v[3]
	D <- p.v[4]
	E <- p.v[5]
	F <- p.v[6]

	J <- A*C-B^2

	if (!fn_is.elps(p.v))
		{stop("Not valid ellipse")
		}

	aligned$h <- (C*D-B*E)/(-J)
	aligned$k <- (A*E-B*D)/(-J)

	aligned$a <- sqrt(2*(A*E^2+C*D^2+F*B^2-2*B*D*E-A*C*F)/((-J)*(sqrt((A-C)^2+4*B^2)-(A+C))))
	aligned$b <- sqrt(2*(A*E^2+C*D^2+F*B^2-2*B*D*E-A*C*F)/((-J)*(-sqrt((A-C)^2+4*B^2)-(A+C))))

	if ((B==0)&(A<C))
		{angle <- 0
		}

	if ((B==0)&(A>C))
		{angle <- pi/2
		}

	if ((B!=0)&(A<C))
		{angle <- .5*atan((2*B)/(A-C))
		}

	if ((B!=0)&(A>C))
		{angle <- pi/2 + .5*atan((2*B)/(A-C))
		}

	# angle between -pi/2 and pi/2
	if (angle > pi/2)
		{angle <- -(pi-angle)
		}

	aligned$psi <- angle

	aligned
	}


fn_aligned.elps_to_canonical <- function(a,b,h,k,psi)
	{
	A <- b^2
	B <- 0
	C <- a^2
	D <- -b^2*h
	E <- -a^2*k
	F <- b^2*h^2 + a^2*k^2 - a^2*b^2

	p.v <- c(A,B,C,D,E,F)

	p.v
}


fn_aligned.elps_to_DE <- function(parm)
{
  parm$aligned$c <- sqrt(parm$aligned$a^2 - parm$aligned$b^2)
    
  parm$de <- NULL
  
  parm$de$e <- sqrt(1-parm$aligned$b^2/parm$aligned$a^2)
  parm$de$l <- parm$aligned$a * (1-parm$de$e^2)
  
  parm$de$psi <- parm$aligned$psi
  
  parm$de$h <- parm$aligned$h + parm$aligned$c * cos(parm$aligned$psi)
  parm$de$k <- parm$aligned$k + parm$aligned$c * sin(parm$aligned$psi)
  
  parm$de$tRange = c(-pi, pi) 
  
  parm
}

fn_DE.elps_to_aligned <- function(parm)
{
  
 parm$aligned <- NULL
 parm$aligned$a <- parm$de$l/(1-parm$de$e^2)
 parm$aligned$b <- sqrt(parm$aligned$a*parm$de$l)
 parm$aligned$psi <- parm$de$psi
  
  c <- sqrt(parm$aligned$a^2 - parm$aligned$b^2)
  
  parm$aligned$h <- parm$de$h - c * cos(parm$aligned$psi)
  parm$aligned$k <- parm$de$k - c * sin(parm$aligned$psi)
  
  parm
}