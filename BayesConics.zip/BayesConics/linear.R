
fn.lin <- function(data)

	{

	################################################################
	# LINEAR LEAST-SQUARES (PSEUDO-INVERSE)
	# SEE ABSTRACT FOR CONFIRMATION THAT PSEUDO-INVERSE IS
	# ONE OF THE TWO LINEAR LS METHODS (OTHER BEING EIGEN ANALYSIS)
	################################################################

	## p. 60 of Sujit da's version
	## Using same overloaded notation as Zhang to find p.v

	b <- -data$y.v^2
	A <- array(,c(data$n,5))
	A[,1] <- data$x.v^2-data$y.v^2
	A[,2] <- 2*data$x.v*data$y.v
	A[,3] <- 2*data$x.v
	A[,4] <- 2*data$y.v
	A[,5] <- 1

	tA.A <- t(A)%*%A
	p.v <- as.vector(solve(tA.A) %*% t(A)%*%b)

	# now fill in C and expand to full parameter vector
	p_lin.v <- array(,6)
	p_lin.v[-3] <- p.v
	p_lin.v[3] <- 1 - p.v[1] 

	##################################

	lin <- NULL
	lin$p.v <- p_lin.v

	lin$check_elps <- fn_is.elps(lin$p.v)
	if (!lin$check_elps) 
		{stop("Not an ellipse!")
		}

	lin$A <- p_lin.v[1]
	lin$B <- p_lin.v[2]
	lin$C <- p_lin.v[3]
	lin$D <- p_lin.v[4]
	lin$E <- p_lin.v[5]
	lin$F <- p_lin.v[6]

	#####

	lin$aligned <- fn_canonical_to_aligned.elps(lin$p.v)

	lin
	}






 