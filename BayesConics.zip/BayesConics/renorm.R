
fn.renorm_w <- function(p.v)
	{
	A <- p.v[1]
	B <- p.v[2]
	C <- p.v[3]
	D <- p.v[4]
	E <- p.v[5]
	F <- p.v[6]

	tmp.v <- (A^2+B^2)*data$x.v^2 + (B^2+C^2)*data$y.v^2 + 2*B*(A+C)*data$x.v*data$y.v
	tmp.v <- tmp.v + 2*(A*D+B*E)*data$x.v + 2*(B*D+C*E)*data$y.v + (D^2+E^2)
	w.v <- 1/tmp.v

	w.v/sum(w.v)*data$n
	}

fn.renorm <- function(renorm_epsilon, data, true)
	
	{
	

	M.mt <- array(,c(6,data$n))
	M.mt[1,] <- data$x.v^2
	M.mt[2,] <- 2*data$x.v*data$y.v
	M.mt[3,] <- data$y.v^2
	M.mt[4,] <- 2*data$x.v
	M.mt[5,] <- 2*data$y.v
	M.mt[6,] <- 1

	N_i.ar <- array(,c(6,6,data$n))
	for (i in 1:data$n)
		{N_i.ar[,,i] <- M.mt[,i] %*% t(M.mt[,i])
		}

	ED.N_i.ar <- array(0,c(6,6,data$n))
	ED.N_i.ar[1,1,] <- 6*data$x.v^2
	ED.N_i.ar[2,1,] <- ED.N_i.ar[1,2,] <- 6*data$x.v*data$y.v
	ED.N_i.ar[3,1,] <- ED.N_i.ar[1,3,] <- data$x.v^2+data$y.v^2
	ED.N_i.ar[4,1,] <- ED.N_i.ar[1,4,] <- 6*data$x.v
	ED.N_i.ar[5,1,] <- ED.N_i.ar[1,5,] <- 2*data$y.v
	ED.N_i.ar[6,1,] <- ED.N_i.ar[1,6,] <- 1
	#
	ED.N_i.ar[2,2,] <- 4*(data$x.v^2+data$y.v^2)
	ED.N_i.ar[2,3,] <- ED.N_i.ar[3,2,] <- 6*data$x.v*data$y.v
	ED.N_i.ar[2,4,] <- ED.N_i.ar[4,2,] <- 4*data$y.v
	ED.N_i.ar[2,5,] <- ED.N_i.ar[5,2,] <- 4*data$x.v
	#
	ED.N_i.ar[3,3,] <- 6*data$y.v^2
	ED.N_i.ar[3,4,] <- ED.N_i.ar[4,3,] <- 2*data$x.v
	ED.N_i.ar[3,5,] <- ED.N_i.ar[5,3,] <- 6*data$y.v
	ED.N_i.ar[3,6,] <- ED.N_i.ar[6,3,] <- 1
	#
	ED.N_i.ar[4,4,] <- 4
	#
	ED.N_i.ar[5,5,] <- 4

	ED.N_i.ar <- true$sigma^2 * ED.N_i.ar

	Q.ar <- array(,c(6,6,data$n))
	for (j in 1:6)
		for (k in j:6)
			{Q.ar[j,k,] <- N_i.ar[j,k,] - ED.N_i.ar[j,k,]
			Q.ar[k,j,] <- Q.ar[j,k,]
			}

	##########################
	
	c <- .1
	w.v <- runif(n=data$n, min=.9, max=1.1) #rep(1, data$n)
	w.v <- w.v/sum(w.v)*data$n
	redo <- TRUE
 
 	while(redo)
		{
	
		hat_N.mt <- array(,c(6,6))
	
		for (j in 1:6)
		for (k in j:6)
			{hat_N.mt[j,k] <- sum(w.v*Q.ar[j,k,])
			hat_N.mt[k,j] <- hat_N.mt[j,k]
			}

		ED_N.mt <- array(,c(6,6))
		for (j in 1:6)
		for (k in j:6)
			{ED_N.mt[j,k] <- sum(w.v*ED.N_i.ar[j,k,])
			ED_N.mt[k,j] <- ED_N.mt[j,k]
			}


		tmp <- eigen(hat_N.mt)

		indx_min <- which.min(tmp$val)
		lam_min <- tmp$val[indx_min]

		p.v <- tmp$vectors[,indx_min]

		del.c <- c*lam_min/as.vector(t(p.v)%*%ED_N.mt%*%p.v)
		c <- c + del.c
		redo <- abs(del.c) > renorm_epsilon

		w.v <- fn.renorm_w(p.v)
		
		}

	################

	renorm <- NULL
	renorm$p.v <- p.v

	renorm$check_elps <- fn_is.elps(renorm$p.v)
	if (!renorm$check_elps) 
		{stop("Not an ellipse!")
		}

	renorm$A <- p.v[1]
	renorm$B <- p.v[2]
	renorm$C <- p.v[3]
	renorm$D <- p.v[4]
	renorm$E <- p.v[5]
	renorm$F <- p.v[6]

	#####

	renorm$aligned <- fn_canonical_to_aligned.elps(renorm$p.v)

	renorm
	}