Mode <- function(x) {
  ux <- unique(x)
  ux[which.max(tabulate(match(x, ux)))]
}

fn.standardAngle <- function(psi)

{ # assuming psi > -2*pi and psi < 2*pi
  if (psi < 0) {psi = psi + 2*pi}
  
  quadrant = psi %/% (pi/2) + as.numeric(psi %% (pi/2) != 0)
  
  # makes it between -pi/2, pi/2
  white.psi = atan(tan(psi))
  
  if (quadrant == 2)
    {white.psi = white.psi + pi}
  
  if (quadrant == 3)
  {white.psi = white.psi - pi}
  
  # now white.psi lies between -pi and pi
  
  white.psi
}

fn.initPsi <- function(parm)
{ A <- parm$A
  B <- parm$B
  C <- parm$C
  D <- parm$D
  E <- parm$E
  F <- parm$F
  
  # between -pi/4 and pi/4
  .5*atan((2*B)/(A-C))
}


fnDE.getTrueConicsPonts <- function(parm)
{
    l <- parm$de$l
    e <- parm$de$e
    h <- parm$de$h
    k <- parm$de$k
    psi <- parm$de$psi
    t.v <- parm$de$t.v
    r.v <- l/(1+e*cos(t.v))

    parm$x.v <- h + r.v*cos(t.v+psi)
    parm$y.v <- k + r.v*sin(t.v+psi)
    
    parm
}


fnDE.log.lik <- function(data, tmp.parm)
{
  tmp.parm <- fnDE.getTrueConicsPonts(tmp.parm)
  
  eps_sq.v <- (data$x.v-tmp.parm$x.v)^2 + (data$y.v-tmp.parm$y.v)^2
  
  tmp.parm$log.lik <- -.5/tmp.parm$de$sigma^2*sum(eps_sq.v)
  
  tmp.parm$log.lik <- tmp.parm$log.lik - data$n*log(2*pi) -2*data$n*log(tmp.parm$de$sigma)
  
  tmp.parm$log.lik
}


fnDE.possibleConic <- function(tryPsi, data, parm)
  {
  
  parm$psi <- tryPsi
  
  data$XY.mt <- array(,c(2,data$n))
  data$XY.mt[1,] <- data$x.v
  data$XY.mt[2,] <- data$y.v
  
  parm$rot.mt <- array(,c(2,2))
  parm$rot.mt[1,] <- c(cos(parm$psi), sin(parm$psi))
  parm$rot.mt[2,] <- c(-sin(parm$psi), cos(parm$psi))
  
  data$XY_star.mt <- parm$rot.mt %*% data$XY.mt
  data$x_star.v <- data$XY_star.mt[1,]
  data$y_star.v <- data$XY_star.mt[2,]
  
  ################################
  
  options(warn=2)
  
  # initial log-likelihood of the 3 conics
  initLogLik <- array(,3)
  
  #############################################
  ### ELLIPSE??
  #############################################
  
  # assuming it's an ellipse, find initial estimates
  tmp <- try(fn.initEllipse(data, parm), silent = TRUE)
  
  if (mode(tmp)=="character")
  {
    initLogLik[1] <- -Inf
  }
  
  if (mode(tmp)!="character")
  { parm <- tmp
  parm$aligned <- parm$init_elps
  
  ################
  # DE parametrization
  ###############
  
  parm <- fn_aligned.elps_to_DE(parm)
  
  ################
  # COMPUTE t_i's for current state
  ###############
  
  parm <- fnDE_ortho_dist(data, parm)
  parm$de$t.v <- parm$de$min_t.v
  parm$de$min_t.v <- NULL
  
  ################
  # sigma
  ###############
  
  parm <- fnDE.sigma(data, parm)
  
  ################
  # Bernstein degree
  ###############
  
  parm$bern_degree <- bern_degree 
  parm$de$p_t.v <- rgamma(n=(parm$bern_degree+1),shape=1)
  parm$de$p_t.v <- parm$de$p_t.v / sum(parm$de$p_t.v)
  
  parm$de$t_bern.v <- sample(1:(parm$bern_degree+1),size=data$n, prob= parm$de$p_t.v, replace=TRUE)
  
  initLogLik[1] <- fnDE.log.lik(data, parm)
  }
  
  #############################################
  ### PARABOLA??
  #############################################
  
  # assuming it's a parabola, find initial estimates
  tmp <- try(fn.initParabola(data, parm), silent = TRUE)
  
  if (mode(tmp)=="character")
  {
    initLogLik[2] <- -Inf
  }
  
  if (mode(tmp)!="character")
  { parm <- tmp
  parm$aligned <- parm$init_prbl
  
  ################
  # DE parametrization
  ###############
  
  parm <- fn_aligned.prbl_to_DE(parm)
  
  ################
  # COMPUTE t_i's for current state
  ###############
  
  parm <- fnDE_ortho_dist(data, parm)
  parm$de$t.v <- parm$de$min_t.v
  parm$de$min_t.v <- NULL
  
  # plot(parm$de$min_x.v, parm$de$min_y.v)
  
  ################
  # sigma
  ###############
  
  parm <- fnDE.sigma(data, parm)
  
  ################
  # Bernstein degree
  ###############
  
  parm$bern_degree <- bern_degree 
  parm$de$p_t.v <- rgamma(n=(parm$bern_degree+1),shape=1)
  parm$de$p_t.v <- parm$de$p_t.v / sum(parm$de$p_t.v)
  
  parm$de$t_bern.v <- sample(1:(parm$bern_degree+1),size=data$n, prob= parm$de$p_t.v, replace=TRUE)
  
  initLogLik[2] <- fnDE.log.lik(data, parm)
  }
  
  
  #############################################
  ### HYPERBOLA??
  #############################################
  
  # assuming it's a hyperbola, find initial estimates
  tmp <- try(fn.initHyperbola(data, parm), silent = TRUE)
  
  if (mode(tmp)=="character")
  {
    initLogLik[3] <- -Inf
  }
  
  if (mode(tmp)!="character")
  { parm <- tmp
  parm$aligned <- parm$init_hybl
  
  ################
  # DE parametrization
  ###############
  
  parm <- fn_aligned.hypl_to_DE(parm)
  
  ################
  # COMPUTE t_i's for current state
  ###############
  
  parm <- fnDE_ortho_dist(data, parm)
  parm$de$t.v <- parm$de$min_t.v
  parm$de$min_t.v <- NULL
  
  # plot(parm$de$min_x.v, parm$de$min_y.v)
  
  ################
  # sigma
  ###############
  
  parm <- fnDE.sigma(data, parm)
  
  ################
  # Bernstein degree
  ###############
  
  parm$bern_degree <- bern_degree 
  parm$de$p_t.v <- rgamma(n=(parm$bern_degree+1),shape=1)
  parm$de$p_t.v <- parm$de$p_t.v / sum(parm$de$p_t.v)
  
  parm$de$t_bern.v <- sample(1:(parm$bern_degree+1),size=data$n, prob= parm$de$p_t.v, replace=TRUE)
  
  initLogLik[3] <- fnDE.log.lik(data, parm)
  }
  
  parm$initLogLik <- initLogLik
  
  list(data, parm)
  }



fnDE.init_conic <- function(data, mh_psi_const, mh_ti_const, mh_l_const, mh_e_const, Big_h, Big_k, Big_l, Big_sigma)

	{

    A <- array(,c(data$n,6))
    A[,1] <- data$x.v^2
    A[,2] <- 2*data$x.v*data$y.v
    A[,3] <- data$y.v^2
    A[,4] <- 2*data$x.v
    A[,5] <- 2*data$y.v
    A[,6] <- 1
    
    tA.A <- t(A)%*%A
    
    tmp <- eigen(tA.A)
    
    p_parm.v <- tmp$vectors[,6]
    
    ##################################
    
    parm <- NULL
    parm$p.v <- p_parm.v
    
    parm$A <- p_parm.v[1]
    parm$B <- p_parm.v[2]
    parm$C <- p_parm.v[3]
    parm$D <- p_parm.v[4]
    parm$E <- p_parm.v[5]
    parm$F <- p_parm.v[6]
    
  #################
  
  initPsi <- fn.initPsi(parm)
  
  max.InitLogLik <- array(,4)
  tryPsi.v <- initPsi + pi*(0:3)/2
  
  tryPsi.v = sapply(tryPsi.v, fn.standardAngle)
  
  for (cc in 1:4)
    {tryPsi <- tryPsi.v[cc]
    tmp <- fnDE.possibleConic(tryPsi, data, parm)
    parm <- tmp[[2]]
    max.InitLogLik[cc] <- max(parm$initLogLik)
  }
  
  pickPsi <- tryPsi.v[which.max(max.InitLogLik)]
  tmp <- fnDE.possibleConic(pickPsi, data, parm)
  data <- tmp[[1]]
  parm <- tmp[[2]]
 
  ###############
  # PICK A CONIC
  ################
  
  if (max(parm$initLogLik)==-Inf)
  {# randomly pick a conic
    parm$initLogLik <- rep(0,3)
  }
  
  parm$initLogLik = parm$initLogLik - max(parm$initLogLik)
  
  parm$initLik <- exp(parm$initLogLik)/sum(exp( parm$initLogLik))
  # never pick circle initially
  parm$de$e_cat = sample(c(2,3,4),size=1,prob=parm$initLik)

  #############################################
  ### IF ELLIPSE WAS SELECTED
  #############################################
  
  if (parm$de$e_cat==2)
  {
    parm <- fn.initEllipse(data, parm)
  
  parm$aligned <- parm$init_elps
  
  ################
  # DE parametrization
  ###############
  
  parm <- fn_aligned.elps_to_DE(parm)
   
  parm$de$e_cat=2
  
  ################
  # COMPUTE t_i's for current state
  ###############
  
  parm <- fnDE_ortho_dist(data, parm)
  parm$de$t.v <- parm$de$min_t.v
  parm$de$min_t.v <- NULL
  
  ################
  # sigma
  ###############
  
  parm <- fnDE.sigma(data, parm)
  
  ################
  # Bernstein degree
  ###############
  
  parm$bern_degree <- bern_degree 
  parm$de$p_t.v <- rgamma(n=(parm$bern_degree+1),shape=1)
  parm$de$p_t.v <- parm$de$p_t.v / sum(parm$de$p_t.v)
  
  parm$de$t_bern.v <- sample(1:(parm$bern_degree+1),size=data$n, prob= parm$de$p_t.v, replace=TRUE)
  
  }
  
  #############################################
  ### IF PARABOLA WAS SELECTED
  #############################################
  
  if (parm$de$e_cat==3)
  {
    parm <- fn.initParabola(data, parm)
  parm$aligned <- parm$init_prbl
  
  ################
  # DE parametrization
  ###############
  
  parm <- fn_aligned.prbl_to_DE(parm)

  parm$de$e_cat=3
  
  ################
  # COMPUTE t_i's for current state
  ###############
  
  parm <- fnDE_ortho_dist(data, parm)
  parm$de$t.v <- parm$de$min_t.v
  parm$de$min_t.v <- NULL
  
  ################
  # sigma
  ###############
  
  parm <- fnDE.sigma(data, parm)
  
  ################
  # Bernstein degree
  ###############
  
  parm$bern_degree <- bern_degree 
  parm$de$p_t.v <- rgamma(n=(parm$bern_degree+1),shape=1)
  parm$de$p_t.v <- parm$de$p_t.v / sum(parm$de$p_t.v)
  
  parm$de$t_bern.v <- sample(1:(parm$bern_degree+1),size=data$n, prob= parm$de$p_t.v, replace=TRUE)
  
  }
  
  
  #############################################
  ### IF HYPERBOLA WAS SELECTED
  #############################################
  
  if (parm$de$e_cat==4)
  {
    parm <- fn.initHyperbola(data, parm)
  parm$aligned <- parm$init_hybl
  
  ################
  # DE parametrization
  ###############
  
  parm <- fn_aligned.hypl_to_DE(parm)
  
  parm$de$e_cat=4
  
  ################
  # COMPUTE t_i's for current state
  ###############
  
  parm <- fnDE_ortho_dist(data, parm)
  parm$de$t.v <- parm$de$min_t.v
  parm$de$min_t.v <- NULL
  
  # plot(parm$de$min_x.v, parm$de$min_y.v)
  
  ################
  # sigma
  ###############
  
  parm <- fnDE.sigma(data, parm)
  
  ################
  # Bernstein degree
  ###############
  
  parm$bern_degree <- bern_degree 
  parm$de$p_t.v <- rgamma(n=(parm$bern_degree+1),shape=1)
  parm$de$p_t.v <- parm$de$p_t.v / sum(parm$de$p_t.v)
  
  parm$de$t_bern.v <- sample(1:(parm$bern_degree+1),size=data$n, prob= parm$de$p_t.v, replace=TRUE)
  
  }
  
  
  ##################
	
	parm$mh_psi_const <- mh_psi_const
	parm$mh_ti_const <- mh_ti_const
	parm$mh_l_const <- mh_l_const
	parm$mh_e_const <- mh_e_const
	
	####
	# for beta density
	parm$betaConst = NULL
	vec = 1:(parm$bern_degree+1)
	parm$betaConst$c1 = vec
	parm$betaConst$c2 = (parm$bern_degree+2-vec)
	parm$betaConst$LogBetaFn.v = lbeta(parm$betaConst$c1,parm$betaConst$c2)
	
	parm
	}


fnDE.sigma <- function(data, parm)
{
  parm <- fnDE.getTrueConicsPonts(parm)
  
  eps_sq.v <- (data$x.v-parm$x.v)^2 + (data$y.v-parm$y.v)^2
  
  parm$de$sigma <- 1/sqrt(rgamma(n=1, shape=(data$n+1), rate=sum(eps_sq.v)/2))
  
  parm
}

fnDE.gen_location <- function(data, parm)
	{
  l <- parm$de$l
  e <- parm$de$e
  h <- parm$de$h
  k <- parm$de$k
  psi <- parm$de$psi
  t.v <- parm$de$t.v
  r.v <- l/(1+e*cos(t.v))
  
	x.v <- data$x.v -r.v*cos(t.v+psi)
	y.v <- data$y.v -r.v*sin(t.v+psi)

	parm$mu.v <- c(mean(x.v), mean(y.v))
	parm$sd.mt <- parm$de$sigma*diag(2)/data$n

	vec <- rmvnorm(n=1, mean=parm$mu.v, sigma=parm$sd.mt)
		

	parm$de$h <- vec[1]
	parm$de$k <- vec[2]
		
	parm	
	}

###################################


log.dens.e <- function(e_star, data, parm)
{ 
  tmp.parm <- parm
  tmp.parm$de$e <- e_star
  
  fnDE.log.lik(data, tmp.parm)
  
}

deri_L.e <- function(e_star, data, parm, eps=2*pi/1000)
  {

  val1  <- log.dens.e((e_star+eps/2), data, parm)
  val2 <- log.dens.e((e_star-eps/2), data, parm)
  
  (val1-val2)/eps
  }

deri2_L.e2 <- function(e_star, data, parm, eps=2*pi/1000)
{

  val1  <- deri_L.e((e_star+eps), data, parm)
  val2 <- deri_L.e((e_star-eps), data, parm)
  
  (val1-val2)/eps/2
}



fnDE.gen_e_t.v <- function(data, parm, mh_e_const)
{
  der2 <- deri2_L.e2(e_star=parm$de$e, data, parm, eps=2*pi/1000)
  parm$convex_e.flag <- as.numeric(der2 > 0)
  
  e_sd <- parm$mh_e_const/sqrt(abs(der2))
  
  approx.log.post.dens <- dnorm(parm$de$e,mean=parm$de$e,sd=e_sd,log=TRUE)
  
  log.joint.dens <- log.dens.e(e_star=parm$de$e, data, parm) + dgamma(parm$de$e,shape=1,scale=1/log(2),log=TRUE) + log(19/30)
  approx.log.marg.lik <- log.joint.dens - approx.log.post.dens
  
  log.prob.v <- array(,3)
  log.prob.v[1] <-log.dens.e(e_star=0, data, parm) + log(1/30)
  log.prob.v[2] <-log.dens.e(e_star=1, data, parm) + log(1/3)
  log.prob.v[3] <- approx.log.marg.lik + log(19/30)
  log.prob.v <- log.prob.v - max(log.prob.v)
  
  ###################################
  new.parm <- parm
  
  new.parm$de$e_cat <- sample(c(1,3,9), size=1, prob=exp(log.prob.v))
  
  new.parm$de$tRange = c(-pi, pi) 
  
  if (new.parm$de$e_cat==1)
    {new.parm$de$e=0
    new.parm$e_flip <- 1
    parm <- new.parm
    }
  
  if (new.parm$de$e_cat==3)
    {new.parm$de$e=1
    new.parm$e_flip <- 1
    parm <- new.parm
    }
  
  if (new.parm$de$e_cat==9)
    {
  
    new.parm$de$eUpper = Inf
    
    t_max = max(abs(new.parm$de$t.v))
    
    if (t_max > pi/2)
      {new.parm$de$eUpper = -1/cos(t_max)
      }
  
    upper.u <- pnorm(new.parm$de$eUpper,mean=parm$de$e,sd=e_sd)
    u <- runif(n=1, max=upper.u)
    new.parm$de$e <- qnorm(u,mean=parm$de$e,sd=e_sd)
  
    log.ratio <- log.dens.e(e_star=new.parm$de$e, data, parm) - log.dens.e(e_star=parm$de$e, data, parm)
    log.ratio <- min(log.ratio,0)
    e_flip <- rbinom(n=1,size=1,prob=exp(log.ratio))
  
    if (e_flip==1)
      {parm <- new.parm
    }
  
    parm$e_flip <- e_flip
  
    if (parm$de$e > 1) # hyperbola
      {# recompute psi range
      parm$de$tRange = c(-acos(-1/parm$de$e), acos(-1/parm$de$e)) 
      parm$de$e_cat=4
    }
    
    if (parm$de$e < 1) # ellipse
    {parm$de$e_cat=2
    }
    
  } # end big  if (new.parm$de$e_cat==3) loop 
    
  ################
  # 	COMPUTE t_i's 
  ###############
  
  parm <- fn.gen_t.v(data, parm)
  
  parm	
}

###################################


log.dens.l <- function(l_star, data, parm)
{ 
  tmp.parm <- parm
  tmp.parm$de$l <- l_star
  
  fnDE.log.lik(data, tmp.parm)
  
}

deri_L.l <- function(l_star, data, parm, eps=2*pi/1000)
{
  val1  <- log.dens.l((l_star+eps/2), data, parm)
  val2 <- log.dens.l((l_star-eps/2), data, parm)
  
  (val1-val2)/eps
}

deri2_L.l2 <- function(l_star, data, parm, eps=2*pi/1000)
{
  val1  <- deri_L.l((l_star+eps), data, parm)
  val2 <- deri_L.l((l_star-eps), data, parm)
  
  (val1-val2)/eps/2
}



fnDE.gen_l <- function(data, parm, mh_l_const)
{
  
  l_sd <- parm$mh_l_const/sqrt(-deri2_L.l2(l_star=parm$de$l, data, parm, eps=2*pi/1000))
  
  new.parm <- parm
  lower.u <- pnorm(0,mean=parm$de$l,sd=l_sd)
  u <- runif(n=1, min=lower.u)
  new.parm$de$l <- qnorm(u,mean=parm$de$l,sd=l_sd)
  
  log.ratio <- log.dens.l(l_star=new.parm$de$l, data, parm) - log.dens.l(l_star=parm$de$l, data, parm)
  log.ratio <- min(log.ratio,0)
  l_flip <- rbinom(n=1,size=1,prob=exp(log.ratio))
  
  if (l_flip==1)
  {parm <- new.parm
  }
  
  parm$l_flip <- l_flip
  
  parm	
}

#############################################

log.dens.psi <- function(psi_star, data, parm)
{ 
  tmp.parm <- parm
  tmp.parm$de$psi <- psi_star
  
  fnDE.log.lik(data, tmp.parm) 
}

deri_L.psi <- function(psi_star, data, parm, eps=2*pi/1000)
{
  
  val1  <- log.dens.psi((psi_star+eps/2), data, parm)
  val2 <- log.dens.psi((psi_star-eps/2), data, parm)
  
  (val1-val2)/eps
}

deri2_L.psi2 <- function(psi_star, data, parm, eps=2*pi/1000)
{
  
  val1  <- deri_L.psi((psi_star+eps), data, parm)
  val2 <- deri_L.psi((psi_star-eps), data, parm)
  
  (val1-val2)/eps/2
}



fnDE.gen_psi <- function(data, parm, mh_psi_const)
{
  
  psi_sd <- parm$mh_psi_const/sqrt(-deri2_L.psi2(psi_star=parm$de$psi, data, parm, eps=2*pi/1000))
  
  new.parm <- parm
  
  # for hypoerbola, psi support does NOT depend on e
  # only the t_i supports depend on e
  lower.u <- pnorm(-pi,mean=parm$de$psi,sd=psi_sd)
  upper.u <- pnorm(pi,mean=parm$de$psi,sd=psi_sd)
  u <- runif(n=1, min=lower.u, max=upper.u)
  new.parm$de$psi <- qnorm(u,mean=parm$de$psi,sd=psi_sd)
  
  log.ratio <- log.dens.psi(psi_star=new.parm$de$psi, data, parm) - log.dens.psi(psi_star=parm$de$psi, data, parm)
  log.ratio <- min(log.ratio,0)
  psi_flip <- rbinom(n=1,size=1,prob=exp(log.ratio))
  
  if (psi_flip==1)
  {parm <- new.parm
  }
  
  parm$psi_flip <- psi_flip
  
  parm$de$psi = fn.standardAngle(parm$de$psi)
  
  parm	
}

log.prior.t_i <- function(t_star, parm, summ=TRUE)
{ val <- val2 <- array(,(parm$bern_degree+1))

  scale_t <- (t_star-parm$de$tRange[1])/diff(parm$de$tRange)
  
  log_scale_t = log(scale_t)
  log_1_scale_t = log(1-scale_t)
  
  val = -parm$betaConst$LogBetaFn.v + (parm$betaConst$c1-1)*log_scale_t + (parm$betaConst$c2-1)*log_1_scale_t
  val = parm$de$p_t.v * exp(val)

  maxx <- max(val)
  ret <- 0
  
  if (maxx > 0)
    {val <- val/maxx
  
    if (summ)
      {ret <- log(maxx) + log(sum(val))
      }
    }
  
  if (!summ)
    {ret <- val
    }
  
  ret
}

log.dens.t_i <- function(t_star, i, data, parm)
{ l <- parm$de$l
  e <- parm$de$e
  h <- parm$de$h
  k <- parm$de$k
  psi <- parm$de$psi
  
  r_star <- l/(1+e*cos(t_star))
  x <- h + r_star*cos(t_star+psi)
  y <- k + r_star*sin(t_star+psi)
  
  eps_sq.i <- (data$x.v[i]-x)^2 + (data$y.v[i]-y)^2
  
  val <- -.5/parm$de$sigma^2*eps_sq.i
  
  val <- val + log.prior.t_i(t_star, parm, summ=TRUE)
  
  val
}


deri_L.t_i <- function(t_star, i, data, parm, eps=2*pi/1000)
{
  t1 = min((t_star+eps/2),0.999*parm$de$tRange[2])
  t2 = max((t_star-eps/2),0.999*parm$de$tRange[1])
  
  val1  <- log.dens.t_i(t1, i, data, parm)
  val2 <- log.dens.t_i(t2, i, data, parm)
  
  (val1-val2)/eps
}


deri2_L.t_i2 <- function(t_star, i, data, parm, eps=2*pi/1000)
{
  t1 = min((t_star+eps),0.999*parm$de$tRange[2])
  t2 = max((t_star-eps),0.999*parm$de$tRange[1])
  
  val1  <- deri_L.t_i(t1, i, data, parm)
  val2 <- deri_L.t_i(t2, i, data, parm)
  
  (val1-val2)/eps/2
}


fn.gen_t_i <- function(i, data, parm)
  {
  der2 <- deri2_L.t_i2(t_star=parm$de$t.v[i], i, data, parm)
  parm$convex_i.flag.v[i] <- as.numeric(der2 > 0)
  
  ti_sd <- parm$mh_ti_const/sqrt(abs(der2))
  
  new.parm <- parm
 
  lower.u <- pnorm(parm$de$tRange[1],mean=parm$de$t.v[i],sd= ti_sd)
  upper.u <- pnorm(parm$de$tRange[2],mean=parm$de$t.v[i],sd= ti_sd)
  u <- runif(n=1, min=lower.u, max=upper.u)
  new.parm$de$t.v[i] <- qnorm(u,mean=parm$de$t.v[i],sd=ti_sd)
  
  log.ratio <- log.dens.t_i(t_star=new.parm$de$t.v[i], i, data, parm) - log.dens.t_i(t_star=parm$de$t.v[i], i, data, parm)
  log.ratio <- min(log.ratio,0)
  ti_flip <- rbinom(n=1,size=1,prob=exp(log.ratio))
  
  if (ti_flip==1)
  {parm <- new.parm
  }
  
  parm$ti_flip.v[i] <- ti_flip
  
  
  parm
}


fn.sample <- function(prob.v)
  {sample(1:length(prob.v), size=1, prob=prob.v)
}



fn.bern.component <- function(parm)
{
  prob.mt <- array(,c(data$n, (parm$bern_degree+1)))

  t_star.v <- (parm$de$t.v-parm$de$tRange[1])/diff(parm$de$tRange)
  
  for (w in 1:(parm$bern_degree+1))
    {prob.mt[,w] <- parm$de$p_t.v[w] * dbeta(t_star.v, shape1=w, shape2=(parm$bern_degree+2-w))
    }
    
  parm$de$t_bern.v <- apply(prob.mt,1,fn.sample)
  
  parm$de$t_bern_summary.v <- array(,(parm$bern_degree+1))
  for (w in 1:(parm$bern_degree+1))
    {parm$de$t_bern_summary.v[w] <- sum(parm$de$t_bern.v==w)
    }
  
  parm$de$p_t.v <- rgamma(n=(parm$bern_degree+1),shape=(1+parm$de$t_bern_summary.v))
  parm$de$p_t.v <- parm$de$p_t.v / sum(parm$de$p_t.v)
  
  parm
  
  }
  
  

fn.gen_t.v <- function(data, parm)
  {
 
  parm$convex_i.flag.v <- parm$ti_flip.v <- rep(NA,data$n)
  
  for (i in 1:data$n)
    {parm <- fn.gen_t_i(i, data, parm)
    }
  
  parm
  
}



fnDE.iter_conic <- function(data, parm)

	{

	################
	# 	UPDATE (h,k)
	###############
	
	parm <- fnDE.gen_location(data, parm)

	################
	# 	UPDATE l
	###############
	
	parm <- fnDE.gen_l(data, parm)
	
	################
	# 	UPDATE e and/or t.v
	###############

	  parm <- fnDE.gen_e_t.v(data, parm)
	
	################
	# 	sigma
	###############
	
	parm <- fnDE.sigma(data, parm)


	################
	# 	UPDATE psi
	###############
	
	parm <- fnDE.gen_psi(data, parm)
	
	#############
	## Generate the components of Bernstein polynomial
	## and update their probabilities
	#############
	
	parm <- fn.bern.component(parm)
	
	parm
	}





fnDE.main_conic <- function(data, n.burn,n.reps, mh_psi_const, mh_ti_const, mh_l_const, mh_e_const, Big_h, Big_k, Big_l, Big_sigma)
  
{
  init.parm <- parm <- fnDE.init_conic(data, mh_psi_const, mh_ti_const, mh_l_const, mh_e_const, Big_h, Big_k, Big_l, Big_sigma)

  for (cc in 1:n.burn)
    {parm <- fnDE.iter_conic(data, parm)
    
    if (cc %% 10 == 0)
    {print(paste("BURNIN",cc,date()))
    }
  }

  DE.Stuff <- NULL
  DE.Stuff$init.parm <- init.parm
  
  DE.Stuff$convex_i.flag.v <- DE.Stuff$ti_flip.v <- rep(0,data$n)
  DE.Stuff$convex_e.flag <- DE.Stuff$l_flip <- DE.Stuff$e_flip <- DE.Stuff$psi_flip <-  0
  DE.Stuff$parm.mt <- array(0,c(6, n.reps))
  dimnames(DE.Stuff$parm.mt) <- list(c("h","k","psi","e","l","sigma"),NULL)
  DE.Stuff$sigma <- 0
  DE.Stuff$p_t.v <- rep(0,(parm$bern_degree+1))
  DE.Stuff$conic.v <- array(,n.reps)

  DE.Stuff$diffTime = array(,n.reps)
  
  for (cc in 1:n.reps)
    {start_time <- Sys.time()
    parm <- fnDE.iter_conic(data, parm)
    end_time <- Sys.time()
    DE.Stuff$diffTime[cc] = difftime(end_time, start_time, units="secs")
    
    DE.Stuff$parm.mt[,cc] <- c(parm$de$h,parm$de$k,parm$de$psi,parm$de$e, parm$de$l, parm$de$sigma)
    
    DE.Stuff$conic.v[cc] <- parm$de$e_cat
    
    DE.Stuff$convex_i.flag.v <- DE.Stuff$convex_i.flag.v + parm$convex_i.flag.v
    DE.Stuff$convex_e.flag <- DE.Stuff$convex_e.flag + parm$convex_e.flag
    DE.Stuff$ti_flip.v <- DE.Stuff$ti_flip.v + parm$ti_flip.v
    
    DE.Stuff$psi_flip <- DE.Stuff$psi_flip + parm$psi_flip
    DE.Stuff$l_flip <- DE.Stuff$l_flip + parm$l_flip
    DE.Stuff$e_flip <- DE.Stuff$e_flip + parm$e_flip
    
    DE.Stuff$sigma <- DE.Stuff$sigma + parm$de$sigma
    
    DE.Stuff$p_t.v <- DE.Stuff$p_t.v + parm$de$p_t.v
    
    if (cc %% 10 == 0)
    {print(paste("ANALYZING",cc,date()))
    }
  }
  
  DE.Stuff$conicsProbs = array(,3)
  for (jj in 2:4)
    {DE.Stuff$conicsProbs[jj-1] = mean(DE.Stuff$conic.v==jj)}

  DE.Stuff$convex_i.flag.v <- DE.Stuff$convex_i.flag.v/n.reps
  DE.Stuff$ti_flip.v <- DE.Stuff$ti_flip.v/n.reps
  DE.Stuff$psi_flip <- DE.Stuff$psi_flip/n.reps
  DE.Stuff$l_flip <- DE.Stuff$l_flip/n.reps
  DE.Stuff$e_flip <- DE.Stuff$e_flip/n.reps
  DE.Stuff$sigma <- DE.Stuff$sigma/n.reps
  DE.Stuff$p_t.v <- DE.Stuff$p_t.v/n.reps
  DE.Stuff$convex_e.flag <- DE.Stuff$convex_e.flag/n.reps
  
  DE.Stuff$detectedConic = Mode(DE.Stuff$conic.v)
  
  DE.Stuff$parm <- parm
  
  ####################
  ### summary in terms of aligned ellipse
  ####################
  
  tmp <- as.vector(rowMeans(DE.Stuff$parm.mt))
  est.e <- tmp[4]
  est.l <- tmp[5]
  est.psi <- tmp[3]
  est.h <- tmp[1]
  est.k <- tmp[2]
  est.sigma <- tmp[6]
  #
  est.parm <- NULL
  est.parm$de <- NULL
  est.parm$de$e <- est.e
  est.parm$de$l <- est.l
  est.parm$de$psi <- est.psi
  est.parm$de$h <- est.h
  est.parm$de$k <- est.k
  est.parm$de$sigma <- est.sigma
  
  if (est.parm$de$e<1)
  {est.parm$de$tRange = c(-pi,pi)
  }
  if (est.parm$de$e>1)
    {est.parm$de$tRange = c(-acos(-1/est.parm$de$e), acos(-1/est.parm$de$e)) 
  }
  if (est.parm$de$e==1)
  {est.parm$de$tRange = parm$de$tRange
  }
  
  if (est.parm$de$e < 1)
  {
  
    DE.Stuff$est.parm <- est.parm <- fn_DE.elps_to_aligned(est.parm)
  }
  
  if (est.parm$de$e > 1)
  {
    DE.Stuff$est.parm <- est.parm <- fn_DE.hypl_to_aligned(est.parm)
  }
  
  if (est.parm$de$e == 1)
  {
    DE.Stuff$est.parm <- est.parm <- fn_DE.prbl_to_aligned(est.parm)
  }

  ##########
  DE.Stuff$cor.mt = diag(5)
  
  if (sum(apply(DE.Stuff$parm.mt[-6,],1,sd) > 0)==5)
    {DE.Stuff$cor.mt = cor(t(DE.Stuff$parm.mt))
    }
  
  DE.Stuff$diffTime = mean(DE.Stuff$diffTime)
  ############
  DE.Stuff
}
