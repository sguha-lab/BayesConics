

fnL.init_ellipse <- function(data)

	{

	b <- -data$y.v^2
	A <- array(,c(data$n,5))
	A[,1] <- data$x.v^2-data$y.v^2
	A[,2] <- 2*data$x.v*data$y.v
	A[,3] <- 2*data$x.v
	A[,4] <- 2*data$y.v
	A[,5] <- 1

	tA.A <- t(A)%*%A
	p.v <- as.vector(solve(tA.A) %*% t(A)%*%b)

	p_parm.v <- array(,6)
	p_parm.v[-3] <- p.v
	p_parm.v[3] <- 1 - p.v[1] 

	##################################

	parm <- NULL
	parm$p.v <- p_parm.v

	parm$A <- p_parm.v[1]
	parm$B <- p_parm.v[2]
	parm$C <- p_parm.v[3]
	parm$D <- p_parm.v[4]
	parm$E <- p_parm.v[5]
	parm$F <- p_parm.v[6]

	#####

	parm$check_elps <- fn_is.elps(parm$p.v)
	if (!parm$check_elps) 
		{stop("Not an ellipse!")
		}


	parm$aligned <- fn_canonical_to_aligned.elps(parm$p.v)
	# using only psi for angle in Bayesian
	parm$aligned$angle <- NULL

	parm$check_elps <- fn_is.elps(parm$p.v)
	if (!parm$check_elps) 
		{stop("Not an ellipse!")
		}

	parm
	}



fn.log.lik.psi <- function(psi, data, parm)
	{
	h <- parm$aligned$h
	k <- parm$aligned$k
	a <- parm$aligned$a
	b <- parm$aligned$b
	t.v <- parm$min_t.v
	n <- data$n

	log.lik <- sum((data$x.v -h-a*cos(t.v)*cos(psi) +b*sin(t.v)*sin(psi))^2)
	log.lik <- log.lik + sum((data$y.v -k-a*cos(t.v)*sin(psi) -b*sin(t.v)*cos(psi))^2)	
	
	log.lik
	}



fnL2.gen_psi <- function(data, parm)
	{
	
	tmp <- optimize(fn.log.lik.psi, interval=c(-pi/2,pi/2), data, parm)
	parm$aligned$psi <- tmp$minimum

	parm	
	}


fnL.sigma <- function(data, parm)
	{
	V <- sum(parm$min_dist.v^2)

	parm$sigma <- sqrt(V/data$n)

	parm
	}


fn.ortho_lse <- function(data, parm)
	{
	psi <- parm$aligned$psi
	old.parm <- parm

	### STEP 1: compute orthogonal distances
	parm <- fn2_ortho_dist(data, parm)
	
	### STEP 2: jointly update (h,k,a,b)
	parm$D <- array(0,c(2*data$n, 4))

	# h, k, a, b
	parm$D[1:data$n,1] <- 1
	parm$D[1:data$n,2] <- 0
	parm$D[1:data$n,3] <- cos(parm$min_t.v)*cos(psi)
	parm$D[1:data$n,4] <- -sin(parm$min_t.v)*sin(psi)
	#
	parm$D[-(1:data$n),1] <- 0
	parm$D[-(1:data$n),2] <- 1
	parm$D[-(1:data$n),3] <- cos(parm$min_t.v)*sin(psi)
	parm$D[-(1:data$n),4] <- sin(parm$min_t.v)*cos(psi)

	vec <- c(data$x.v, data$y.v)

	tmp <- summary(lm(vec ~ parm$D - 1))$coeff
	parm$aligned$h <- tmp[1,1]
	parm$aligned$k <- tmp[2,1]
	parm$aligned$a <- tmp[3,1]
	parm$aligned$b <- tmp[4,1]

	parm$lse_se <- as.vector(tmp[,2])

	parm$p.v <- fn_aligned.elps_to_canonical(parm$aligned$a,parm$aligned$b,parm$aligned$h,parm$aligned$k)
	parm$A <- parm$p.v[1]
	parm$B <- parm$p.v[2]
	parm$C <- parm$p.v[3]
	parm$D <- parm$p.v[4]
	parm$E <- parm$p.v[5]
	parm$F <- parm$p.v[6]

	### STEP 3: Update psi

	parm <- fnL2.gen_psi(data, parm)

	### STEP 4: Evaluate relative change in estimates

	diff <- unlist(parm$aligned) - unlist(old.parm$aligned)
	indx <- unlist(parm$aligned) != 0
	parm$ratio <- mean((diff[indx] / unlist(old.parm$aligned[indx]))^2)
	
	parm
	}


fn.ortho_parm <- function(data, eps_ortho = 1e-4, max.iter=100)
	{


	ortho_parm  <- fnL.init_ellipse(data)

	ortho_parm$ratio <- 1
	ortho_parm$iter <- 0

	while ((ortho_parm$ratio > eps_ortho) & (ortho_parm$iter < max.iter))
		{ortho_parm <- fn.ortho_lse(data, ortho_parm)
		ortho_parm$iter <- ortho_parm$iter + 1
		}

	ortho_parm <- fnL.sigma(data, ortho_parm)

	ortho_parm
	}

